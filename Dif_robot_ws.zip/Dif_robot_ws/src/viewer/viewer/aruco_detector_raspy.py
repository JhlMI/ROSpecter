import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage
from cv_bridge import CvBridge
from std_msgs.msg import String
import numpy as np
import cv2

class ImageSubscriber(Node):
    def __init__(self):
        super().__init__('image_subscriber')
        self.subscription = self.create_subscription(
            CompressedImage,
            '/image_raw/compressed',  
            self.listener_callback,
            10)
        
        self.publisher_ = self.create_publisher(CompressedImage, 'processed_image/compressed', 10)
        self.coordinates_publisher = self.create_publisher(String, 'aruco/coordinates', 10)
        self.subscription  
        self.bridge = CvBridge()
        self.aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
        self.aruco_params = cv2.aruco.DetectorParameters()
        self.last_coordinates = "ID: -1, X: -1, Y: -1"  # Inicialmente, no hay datos válidos
        self.get_logger().info("Aruco Detector Node Started")

    def listener_callback(self, msg):
        self.get_logger().info('Receiving compressed image frame')
        try:
            # Decodificar la imagen
            np_arr = np.frombuffer(msg.data, np.uint8)
            current_frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

            coordinates_msg = String()
            # Pipeline de detección de ArUco
            corners, ids, _ = cv2.aruco.detectMarkers(current_frame, self.aruco_dict, parameters=self.aruco_params) 

            if len(corners) > 0:
                current_frame = cv2.aruco.drawDetectedMarkers(current_frame, corners, ids)

                for i, corner in enumerate(corners):
                    c = corner.reshape((4, 2))
                    x = c[:, 0]
                    y = c[:, 1]

                    center_x = int(np.mean(x))
                    center_y = int(np.mean(y))
                    
                    # Actualizar las últimas coordenadas válidas
                    self.last_coordinates = f"ID: {ids[i][0]}, X: {center_x}, Y: {center_y}"
                    coordinates_msg.data = self.last_coordinates
                    self.coordinates_publisher.publish(coordinates_msg)

                    current_frame = cv2.circle(current_frame, (center_x, center_y), 10, (0, 0, 255), -1)
                    self.get_logger().info(f"Marcador {ids[i][0]}: Coordenadas centro (x, y) = ({center_x}, {center_y})")
            else:
                self.get_logger().warn("No ArUco codes detected")

                # Publicar las últimas coordenadas válidas si ya existían
                if self.last_coordinates != "ID: -1, X: -1, Y: -1":
                    self.get_logger().info("Using last known coordinates")
                    coordinates_msg.data = self.last_coordinates
                else:
                    # Si no se detectaron ArUco antes, indicar que debe girar
                    self.get_logger().warn("No valid coordinates yet, robot should rotate")
                    coordinates_msg.data = f"ID: -1, X: -1, Y: -1"

                self.coordinates_publisher.publish(coordinates_msg)
            
            # Mostrar la imagen
            cv2.imshow("camera", current_frame)
            cv2.waitKey(1)
            
            # Convertir la imagen procesada a un mensaje comprimido para publicar
            _, buffer = cv2.imencode('.jpg', current_frame)
            processed_image_msg = CompressedImage()
            processed_image_msg.format = "jpeg"
            processed_image_msg.data = np.array(buffer).tobytes()
            self.publisher_.publish(processed_image_msg)

        except Exception as e:
            self.get_logger().error(f"Error al procesar la imagen: {e}")

def main(args=None):
    rclpy.init(args=args)
    image_subscriber = ImageSubscriber()
    rclpy.spin(image_subscriber)
    image_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage
import numpy as np
import cv2

class ImageSubscriber(Node):
    def __init__(self):
        super().__init__('processed_image_subscriber')
        # Se suscribe al topic de imágenes comprimidas
        self.subscription = self.create_subscription(
            CompressedImage,
            '/processed_image/compressed',
            self.listener_callback,
            10)
        self.subscription  # Prevent unused variable warning
        self.get_logger().info("Listening to /processed_image/compressed")

    def listener_callback(self, msg):
        self.get_logger().info('Received processed image')
        
        try:
            # Convertir la imagen comprimida a un formato numpy array
            np_arr = np.frombuffer(msg.data, np.uint8)
            # Decodificar la imagen comprimida en formato OpenCV
            current_frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
            
            # Mostrar la imagen en una ventana
            cv2.imshow("Processed Image", current_frame)
            cv2.waitKey(1)
        
        except Exception as e:
            self.get_logger().error(f"Error al procesar la imagen: {e}")

def main(args=None):
    rclpy.init(args=args)
    image_subscriber = ImageSubscriber()
    rclpy.spin(image_subscriber)
    image_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

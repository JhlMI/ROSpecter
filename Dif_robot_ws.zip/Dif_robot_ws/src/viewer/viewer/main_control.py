import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class ArucoPID(Node):
    def __init__(self):
        super().__init__('aruco_pid')
        self.subscription = self.create_subscription(
            String,
            'aruco/coordinates',  # Tópico de coordenadas del ArUco
            self.listener_callback,
            10)

        self.publisher_ = self.create_publisher(String, 'Data_esp32', 5)  # Tópico de salida PWM

        # Parámetros PID
        self.kp = 0.15
        self.ki = 0.0
        self.kd = 0.5
        self.setpoint = 320  # Centro de la cámara
        self.prev_error = 0.0
        self.integral = 0.0

        self.get_logger().info("PID Node for ArUco Tracking Started")

    def listener_callback(self, msg):
        try:
            data = msg.data

            # Parsear el mensaje
            if "X:" in data:
                parts = data.split(",")
                x = int(parts[1].split(":")[1].strip())
                
                if x == -1:  # Si no se detecta un ArUco
                    self.get_logger().warn("No ArUco detected, rotating...")
                    pwm_msg = String()
                    pwm_msg.data = "0,0"  # Girar en su lugar
                    self.publisher_.publish(pwm_msg)
                    return

                # Calcular error
                error = self.setpoint - x
                if abs(error) <= 25:
                    error = 0

                # Cálculo PID
                self.integral += error
                derivative = error - self.prev_error
                output =int( self.kp * error + self.ki * self.integral + self.kd * derivative)

                self.prev_error = error
                if output > 40:
                    output= 40
                elif output <-40:
                    output= -40

                #output = output + 10
                # Convertir la salida en valores PWM
                #pw1 = max(min(50 + int(output), 60), 0)  # Límite de PWM (0 a 100)
                #pw2 = max(min(50 - int(output), 60), 0)

                # Publicar los valores PWM
                pwm_msg = String()
                pwm_msg.data = f"{-output},{output}"
                self.publisher_.publish(pwm_msg)
                
                self.get_logger().info(f"Error: {error}, PWM: {-output},{output}")

            else:
                self.get_logger().warn("Invalid message format received")

        except Exception as e:
            self.get_logger().error(f"Error in PID callback: {e}")


def main(args=None):
    rclpy.init(args=args)
    pid_node = ArucoPID()
    rclpy.spin(pid_node)
    pid_node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

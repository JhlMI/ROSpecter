import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage
from cv_bridge import CvBridge
import cv2
import numpy as np

class ArucoCalibrator(Node):
    def __init__(self):
        super().__init__('aruco_calibrator')
        self.subscription = self.create_subscription(
            CompressedImage,
            '/image_raw/compressed',
            self.image_callback,
            10
        )
        self.bridge = CvBridge()

        # Tablero ArUco y parámetros
        self.aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
        self.board = cv2.aruco.CharucoBoard((11, 8), 0.015, 0.011, self.aruco_dict)
        self.all_corners = []
        self.all_ids = []
        self.image_size = None
        self.calibration_done = False

        self.get_logger().info("Aruco Calibrator Node Started")

    def image_callback(self, msg):
        # Convertir el mensaje a imagen OpenCV
        try:
            np_arr = np.frombuffer(msg.data, np.uint8)
            frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

            # Detectar los marcadores en la imagen
            corners, ids, _ = cv2.aruco.detectMarkers(frame, self.aruco_dict)
            if len(corners) > 0:
                # Dibujar los marcadores detectados
                cv2.aruco.drawDetectedMarkers(frame, corners, ids)

                # Intentar detectar y refinar las esquinas de los cuadros del tablero
                retval, charuco_corners, charuco_ids = cv2.aruco.interpolateCornersCharuco(
                    corners, ids, frame, self.board
                )

                if retval > 0:
                    # Dibujar las esquinas detectadas
                    cv2.aruco.drawDetectedCornersCharuco(frame, charuco_corners, charuco_ids)

                    # Guardar las esquinas e IDs para calibrar
                    self.all_corners.append(charuco_corners)
                    self.all_ids.append(charuco_ids)

                    # Guardar el tamaño de la imagen
                    if self.image_size is None:
                        self.image_size = (frame.shape[1], frame.shape[0])

                    self.get_logger().info(f"Charuco corners detected: {len(charuco_corners)}")

                    # Comprobar si tenemos suficientes puntos para calibrar
                    if len(self.all_corners) >= 10:  # Puedes ajustar este número según sea necesario
                        self.calibrate_camera()

            # Mostrar la imagen
            cv2.imshow("Calibration Image", frame)
            cv2.waitKey(1)

        except Exception as e:
            self.get_logger().error(f"Error processing image: {e}")

    def calibrate_camera(self):
        if len(self.all_corners) > 0 and self.image_size is not None and not self.calibration_done:
            self.get_logger().info("Starting camera calibration...")

            # Verificar si hay suficientes esquinas
            if len(self.all_corners) < 4:  # Necesitas al menos 4 vistas para calibrar correctamente
                self.get_logger().warn("Not enough corner data for calibration")
                return

            # Calibrar la cámara
            ret, camera_matrix, dist_coeffs, _, _ = cv2.aruco.calibrateCameraCharuco(
                charucoCorners=self.all_corners,
                charucoIds=self.all_ids,
                board=self.board,
                imageSize=self.image_size,
                cameraMatrix=None,
                distCoeffs=None
            )

            if ret:
                self.get_logger().info(f"Calibration successful!")
                self.get_logger().info(f"Camera matrix: \n{camera_matrix}")
                self.get_logger().info(f"Distortion coefficients: \n{dist_coeffs}")
                self.calibration_done = True  # Marcar como calibrado
            else:
                self.get_logger().warn("Calibration failed")
        else:
            self.get_logger().warn("Not enough data for calibration or calibration already done")

def main(args=None):
    rclpy.init(args=args)
    node = ArucoCalibrator()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()
    cv2.destroyAllWindows()

if __name__ == '_main_':
    main()
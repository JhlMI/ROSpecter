import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Joy
from std_msgs.msg import String

class PS4Controller:
    def __init__(self):
        # Botones
        self.Square = 0
        self.Cross = 0
        self.Circle = 0
        self.Triangle = 0
        self.L1 = 0
        self.R1 = 0
        self.L2 = 0
        self.R2 = 0
        self.Share = 0
        self.Options = 0
        self.LStickPress = 0
        self.RStickPress = 0
        self.PS = 0
        self.UP = 0
        self.DOWN = 0
        self.LEFT = 0
        self.RIGHT = 0

        # Joysticks
        self.LStickX = 0.0
        self.LStickY = 0.0
        self.RStickX = 0.0
        self.RStickY = 0.0

    def update(self, joy_msg):
        # Botones
        self.Square = joy_msg.buttons[0]
        self.Cross = joy_msg.buttons[1]
        self.Circle = joy_msg.buttons[2]
        self.Triangle = joy_msg.buttons[3]
        self.L1 = joy_msg.buttons[4]
        self.R1 = joy_msg.buttons[5]
        self.L2 = joy_msg.buttons[6]
        self.R2 = joy_msg.buttons[7]
        self.Share = joy_msg.buttons[8]
        self.Options = joy_msg.buttons[9]
        self.LStickPress = joy_msg.buttons[10]
        self.RStickPress = joy_msg.buttons[11]
        self.PS = joy_msg.buttons[12]

        # Ejes (Joysticks)
        self.UP = joy_msg.axes[7] == 1
        self.DOWN = joy_msg.axes[7] == -1
        self.LEFT = joy_msg.axes[6] == -1
        self.RIGHT = joy_msg.axes[6] == 1

        self.LStickX = joy_msg.axes[0]
        self.LStickY = joy_msg.axes[1]
        self.RStickX = joy_msg.axes[3]
        self.RStickY = joy_msg.axes[4]

class TeleopPS4(Node):
    def __init__(self):
        super().__init__('teleop_ps4_node')
        self.pwm_publisher = self.create_publisher(String, '/Data_esp32', 10)
        self.subscriber = self.create_subscription(Joy, 'joy', self.joy_callback, 10)
        self.PS4 = PS4Controller()  # Instancia de la clase PS4Controller
        
        self.pwm_data = [0, 0]
        self.angle = -1
        self.turbo = False  

    def joy_callback(self, msg):


        #LSX = round(self.PS4.LStickX*100,2)
        #RSX = round(self.PS4.RStickX*100,2)
        # Actualizar el estado del mando
        self.PS4.update(msg)
        #self.angle = -1
        # Ejemplo de uso del estado del mando
        self.angle = -1
        if self.PS4.R2:  # Si se presiona R2
            self.pwm_data = [50, 50]
        elif self.PS4.L2:  # Si se presiona L2
            self.pwm_data = [-50, -50]
        else:
            self.pwm_data = [0, 0]

        # Control angular
        if self.PS4.L1 and not self.PS4.R1:
            self.pwm_data = [-50, 50]
        if not self.PS4.L1 and self.PS4.R1:
            self.pwm_data = [50, -50]

        if self.PS4.UP:
            self.angle = 180

        if self.PS4.RIGHT:
            self.angle = 270

        if self.PS4.LEFT :
            self.angle = 90
        # Turbo
        self.turbo = self.PS4.Triangle 
            
        raw_data = str(self.angle) + "," + str(self.pwm_data[0]) + "," + str(self.pwm_data[1])
        self.pwm_publisher.publish(String(data=raw_data))



def main(args=None):
    rclpy.init(args=args)
    teleop = TeleopPS4()
    rclpy.spin(teleop)
    teleop.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
